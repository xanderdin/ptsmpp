This directory includes the original versions of packages.

smpp.pdu: https://github.com/xanderdin/smpp.pdu
smpp.twisted: https://github.com/xanderdin/smpp.twisted
enum-0.4.4: https://pypi.python.org/packages/source/e/enum/enum-0.4.4.tar.gz
